package com.example.news_dashboard_cross

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
