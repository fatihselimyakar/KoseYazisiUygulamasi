import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:news_dashboard_cross/Models.dart';

import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:async';

class ReadNewsDetail extends StatefulWidget{
  final News news;

  ReadNewsDetail({Key key, @required this.news}) : super(key: key);

  @override
  State<StatefulWidget> createState() => ReadNewsDetailState(news);

}

enum TtsState { playing, stopped, paused, continued }

class ReadNewsDetailState extends State{
  News news;

  FlutterTts flutterTts;
  String language;
  double volume = 0.5;
  double pitch = 1.0;
  double rate = 0.52;
  bool isCurrentLanguageInstalled = false;

  TtsState ttsState = TtsState.stopped;

  get isPlaying => ttsState == TtsState.playing;
  get isStopped => ttsState == TtsState.stopped;
  get isPaused => ttsState == TtsState.paused;
  get isContinued => ttsState == TtsState.continued;

  bool get isIOS => !kIsWeb && Platform.isIOS;
  bool get isAndroid => !kIsWeb && Platform.isAndroid;
  bool get isWeb => kIsWeb;

  @override
  initState() {
    super.initState();
    initTts();
  }

  Future _getEngines() async {
    var engines = await flutterTts.getEngines;
    if (engines != null) {
      for (dynamic engine in engines) {
        print(engine);
      }
    }
  }

  initTts() async{
    flutterTts = FlutterTts();

    if (isAndroid) {
      _getEngines();
    }

    flutterTts.setStartHandler(() {
      setState(() {
        print("Playing");
        ttsState = TtsState.playing;
      });
    });

    flutterTts.setCompletionHandler(() {
      setState(() {
        print("Complete");
        ttsState = TtsState.stopped;
      });
    });

    flutterTts.setCancelHandler(() {
      setState(() {
        print("Cancel");
        ttsState = TtsState.stopped;
      });
    });

    if (isWeb || isIOS) {
      flutterTts.setPauseHandler(() {
        setState(() {
          print("Paused");
          ttsState = TtsState.paused;
        });
      });

      flutterTts.setContinueHandler(() {
        setState(() {
          print("Continued");
          ttsState = TtsState.continued;
        });
      });
    }

    flutterTts.setErrorHandler((msg) {
      setState(() {
        print("error: $msg");
        ttsState = TtsState.stopped;
      });
    });

    await flutterTts.setVolume(volume);
    await flutterTts.setSpeechRate(rate);
    await flutterTts.setPitch(pitch);
    await flutterTts.setLanguage("tr-TR");
  }

  ReadNewsDetailState(News news){
    this.news=news;
  }

  Card listenCard(News news){
    return Card(
      child: ListTile(
        leading: Container(
          width:145,
          height: 50,
          child: Row(
            children: [
              IconButton(
                onPressed: ()async{
                  var result = await flutterTts.speak(news.author+","+news.title+","+news.description);
                  if (result == 1) {
                    setState(() => ttsState = TtsState.playing);
                  }
                },
                icon: Image.asset("images/play.png",height:40,width:40,),
                padding: EdgeInsets.all(1),
              ),
              IconButton(
                onPressed: ()async{
                  var result = await flutterTts.pause();
                  if (result == 1) {
                    setState(() => ttsState = TtsState.paused);
                  }
                },
                icon: Image.asset("images/pause.png",height:40,width:40,),
                padding: EdgeInsets.all(1),
              ),
              IconButton(
                onPressed:  ()async{
                  var result = await flutterTts.stop();
                  if (result == 1) {
                    setState(() => ttsState = TtsState.stopped);
                  }
                },
                icon: Image.asset("images/stop.png",height:40,width:40,),
                padding: EdgeInsets.all(1),
              )
            ],
          ),
        ),
        title: Text(
            "Sesli Dinle",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w400, fontSize: 20.0,
            ),
        ),
        /*subtitle: Text(news.author),*/
        trailing: Icon(Icons.music_note)

      ),
    );
  }

  Widget bodyReturn(context){
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(
              child: CachedNetworkImage(
                  imageUrl: news.urlToImage,
                  placeholder: (context, url) => Center(child:SizedBox(width:100,height:100,child:CircularProgressIndicator())),
                  errorWidget: (context, url, error) => Icon(Icons.error),
              ),
            ),
            Text(
              "\n"+news.title,
              style: TextStyle(
                fontWeight: FontWeight.bold, fontSize: 30.0,
                fontStyle: FontStyle.normal,
                color: Colors.black,
              ),
            ),
            Text(
              "\n"+news.author+" | "+news.publishedAt,
              style: TextStyle(
                fontWeight: FontWeight.w400, fontSize: 18.0,
                fontStyle: FontStyle.normal,
                color: Colors.black,
              ),
            ),
          Text(
            "\n"+news.description,
            style: TextStyle(
              fontWeight: FontWeight.w200, fontSize: 20.0,
              fontStyle: FontStyle.normal,
              color: Colors.black,
            ),
          ),
            Text(
              "\n"+news.url,
              style: TextStyle(
                fontWeight: FontWeight.w200, fontSize: 20.0,
                fontStyle: FontStyle.normal,
                color: Colors.black,
              ),
            ),
            Align(
              child:listenCard(news),
              heightFactor: 1.5,
              /*ElevatedButton(
                onPressed: ()async {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => NewsWebView(news.url)),
                  );
                },
                child: Text(
                    'Detay İçin Tıklayınız',
                    style: TextStyle(fontSize: 20 )
                ),
                style: ButtonStyle(
                  backgroundColor:MaterialStateProperty.all<Color>(Color(0xFF1c2552)),
                ),
              ),*/
            )

          ],
        ),
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Köşe Yazısı Detayı"),
          backgroundColor: Color(0xFF1c2552),
        ),
        body:bodyReturn(context),
    );
  }

}

